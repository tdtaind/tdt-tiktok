"use strict";

// Chạy scripts/configure-extension.mjs từ gói Firebase để điền các giá trị này.
// Khi phát hành chính thức, đặt expectedExtensionId đúng Chrome Web Store ID.
globalThis.TDT_REMOTE_CONFIG = Object.freeze({
  enabled: true,
  serverUrl: "https://tran-duc-tai.web.app",
  projectKey: "tiktok-tai-dep-trai",
  firebaseApiKey: "AIzaSyAvrLb6ncx64RwSbmXWPTp7GdnpgOju80s",
  firebaseDatabaseUrl: "https://tran-duc-tai-default-rtdb.asia-southeast1.firebasedatabase.app",
  expectedExtensionId: "cpndheccadlhkiogcfdhagomiadbaogn",
  heartbeatMinutes: 1,
  requestTimeoutMs: 8000,
  leaseSeconds: 90,
  failMode: "closed",
  privateUpdates: Object.freeze({
    enabled: true,
    manifestUrl: "https://tran-duc-tai.web.app/api/v1/extension/update-manifest",
    manifestFallbackUrls: Object.freeze([
      "https://tran-duc-tai.web.app/extension/releases/latest.json"
    ]),
    releasePageUrl: "https://tran-duc-tai.web.app/extension/",
    checkMinutes: 60,
    autoDownload: true
  })
});
