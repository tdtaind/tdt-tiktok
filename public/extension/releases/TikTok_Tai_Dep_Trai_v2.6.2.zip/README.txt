=== v2.6.2 - Performance, Update Reliability & Final Audit ===

- Giữ nguyên toàn bộ chức năng của v2.6.1.
- Sửa bộ cập nhật: theo dõi trạng thái tải thật, không báo thành công khi file đang tải hoặc bị gián đoạn.
- Tự khôi phục phiên tải cập nhật bị treo sau khi Service Worker khởi động lại.
- Loại URL Cloud Function cũ gây HTTP 404 khỏi chuỗi dự phòng; dùng manifest Hosting tĩnh ngay.
- Giảm tác vụ Audio Spatial và cầu phụ đề khi video tạm dừng hoặc tab ẩn.
- Đồng bộ đủ thống kê tìm ảnh 1688 với Firebase Control v2.3.4.
- Xem RELEASE_NOTES_v2.6.2.txt và TEST_REPORT_v2.6.2.txt.

=== v2.6.0 FINAL - Complete Optimization & Stability Audit ===

- Giữ nguyên toàn bộ chức năng v2.5.3.
- Hoàn thiện player: tôn trọng trạng thái tạm dừng thủ công trong mọi luồng mount/restore/autoplay.
- Proxy TikTok tự xác minh lỗi, tự đổi proxy hỏng và khôi phục kết nối trực tiếp an toàn.
- Tối ưu MutationObserver, timer, quét DOM, Transcript365, bộ lọc, dịch tìm kiếm và TikTok Shop.
- Đồng bộ online bền vững hơn khi Service Worker bị Chrome tạm dừng.
- Giữ nguyên tìm ảnh 1688, chỉ một tab kết quả, tự đóng tab upload và hỗ trợ giao diện AIR mới.
- Xem RELEASE_NOTES_v2.6.0_FINAL.txt và TEST_REPORT_v2.6.0_FINAL.txt.

=== v2.5.0 - Full Performance & Bug Fix Audit ===

- Giữ nguyên toàn bộ chức năng v2.4.4.
- Tối ưu player, bộ lọc, TikTok Shop, tìm ảnh 1688, cache và quét DOM.
- Sửa trang Chào mừng thiếu CSS/JS và các lỗi scheduler/cache/hook phát hiện khi audit.
- Xem RELEASE_NOTES_v2.5.0.txt và TEST_REPORT_v2.5.0.txt.

=== v2.20.0 - Watch Popup, Counter Widget & Compact Video Info ===

- Không tự mở Google Sign-In khi cài mới; đăng nhập chủ động từ popup.
- Watch-time Dashboard và Watch History nằm trong popup.
- Widget bộ đếm trên TikTok hiển thị thời gian và số video hôm nay.
- Video Info dạng bảng nhỏ, mở bằng nút trên thanh điều khiển hoặc phím I.
- Giữ nguyên Extension ID và toàn bộ tính năng cũ.

=== v2.19.0 - Google Auth Visible Redirect ===
- Mở cửa sổ đăng nhập nhìn thấy được trên `tran-duc-tai.firebaseapp.com`.
- Dùng redirect Google/Firebase thay cho popup nằm trong iframe offscreen.
- Kết quả đăng nhập được xác thực bằng nonce 256-bit và Extension ID cố định.
- Phát hiện rõ người dùng đóng cửa sổ hoặc quá thời gian 3 phút.
- Cần deploy Firebase Control v2.2.1 trước khi thử.

TikTok Tài Đẹp Trai - Nhật ký phiên bản

- Nút mũi tên tròn trên thanh tìm kiếm nay đặt lại toàn bộ điều kiện, hiện lại mọi card và chuyển ngay về `Sắp xếp mặc định`.
- Nút Đặt lại trong hộp Lọc dùng cùng một luồng reset ổn định và tự đóng hộp sau khi hoàn tất.
- Thêm phím ←/→ để tua −3/+3 giây, `,`/`.` giảm/tăng tốc độ, `Z` chuyển zoom 1×/1.25×/1.5×/2× và `S` chụp frame.
- Phím tắt chỉ hoạt động khi video thay thế đang mở và không chặn thao tác khi người dùng gõ trong input/textarea/select.

- Sửa video mở từ kết quả tìm kiếm không được thay thế: loại toàn bộ preview/card thuộc `search_top-item-list` và `grid-item-container-*` khỏi danh sách player chính.
- Dựa trên HTML TikTok thực tế, không còn nhận nhầm 48 khối `DivPlayerContainer` của card tìm kiếm là video toàn màn hình đang mở.
- Nút Quét video nay là lệnh cưỡng bức thực sự: hủy lượt mount cũ, chờ player modal xuất hiện tối đa 8 giây, lấy lại URL tab rồi mount đúng video.
- Popup nhận phản hồi thành công/thất bại thật từ content script thay vì luôn báo đã quét dù thao tác chưa chạy.
- Chống xung đột khi người dùng bấm Quét video đúng lúc một lượt tự động đang chạy; lượt cũ không thể gắn nhầm player sau đó.

- Sửa lỗi nhiều trang video TikTok không được thay thế: quét video và player trong cả DOM thường lẫn open Shadow DOM.
- Bổ sung nhận diện `xg-video-container`, `xg-player`, player theo `data-testid` và nhiều cấu trúc TikTok mới; vẫn tránh thay nhầm video preview trên trang profile.
- Tự theo dõi DOM gốc của player, phát hiện host/video thay thế bị TikTok tháo hoặc thay mới và tự mount lại không cần bấm Quét video.
- CSS video thay thế được gắn trực tiếp và chèn đúng Shadow Root, tránh trường hợp player đã tạo nhưng kích thước 0 hoặc nằm sau video gốc.
- Ưu tiên mount đúng container player gần nhất thay vì leo lên khối cha cùng kích thước, tránh video thay thế bị gắn nhầm vào toàn bộ `main/page`.
- Nếu nguồn HD/CORS lỗi, extension tự chuyển sang nguồn video TikTok hiện tại; nếu player lỗi hoặc tải quá thời gian sẽ khôi phục an toàn rồi tự thử lại.

- Sửa lỗi nhận nhầm cả khối kết quả là một card khi TikTok tải thêm nhiều lô; mọi video/bài ảnh giờ được nhận diện theo wrapper gần nhất chứa đúng một Content ID.
- Sửa Auto-Scroll dừng sớm trên giao diện tái sử dụng card: theo dõi đồng thời Content ID mới, dấu vân tay danh sách và chiều cao vùng cuộn thay vì chỉ so sánh số card đang có trong DOM.
- Bổ sung đọc dữ liệu thống kê lồng `itemStruct`, `item_info`, `awemeDetail` và chỉ số dạng `{ value/count/total }`.
- Khôi phục đầy đủ display/order khi tắt bộ lọc, dừng quét dự phòng khi tab ẩn và xử lý lỗi storage an toàn.
- Gộp migration cài đặt Service Worker thành một lần ghi để tránh ghi đè chéo trên bản cài mới; giữ nguyên toàn bộ tính năng video HD, phụ đề, dịch tìm kiếm, Audio Studio.

- Quét thêm theo kiểu Auto-Scroll của KOLSprite: liên tục cuộn thật đến đáy mới, chờ từng lô card ổn định rồi tiếp tục thay vì cuộn–khôi phục vị trí sau mỗi vòng.
- Chỉ kết thúc khi tổng nội dung không tăng trong 6,5 giây; hỗ trợ tối đa 120 nhịp để quét các truy vấn dài.
- Có thể bấm nút quét lần thứ hai để dừng; mọi nội dung đã thu được vẫn được lọc và sắp xếp lại trước khi trả về vị trí ban đầu.

- Chuyển sắp xếp sang cơ chế KOLSprite: đổi trực tiếp thứ tự card trong danh sách TikTok thay vì phụ thuộc vào CSS `order`.
- Mọi đợt tải thêm được gom lại và sắp xếp toàn cục, không chỉ thay đổi 24 card của đợt đầu.
- Chế độ “Lọc lại” toàn bộ nội dung đã tải vẫn được giữ bằng Shift+click nút mũi tên tròn; nút Đặt lại cũng vẫn nằm trong bảng Lọc.

- Sửa sắp xếp/lọc trên kết quả TikTok có trộn video và bài ảnh: mọi card `/video/` và `/photo/` được xử lý trong cùng một danh sách.
- Đọc đúng số cạnh biểu tượng tim (`data-e2e="video-views"`) là lượt thích trên trang tìm kiếm, giúp “Số lượt thích” hoạt động cả khi API chưa trả thống kê cho nội dung tải thêm.
- Bộ lọc Loại nay hoạt động thực sự và hỗ trợ Tất cả, Video hoặc Bài ảnh.

- Sửa bộ lọc/sắp xếp chỉ hoạt động với 24 video mặc định: toàn bộ card thuộc nhiều đợt tải được đưa vào cùng một thứ tự hiển thị chung.
- Tự kiểm tra thứ tự thực tế sau khi TikTok render; nếu CSS `order` không có hiệu lực, extension dùng chế độ sắp xếp DOM an toàn và khôi phục cấu trúc gốc trước lần tải tiếp theo hoặc khi reset.
- Bộ lọc điều kiện được áp dụng cho toàn bộ video đã tải, kể cả 95+ video và các card nằm trong nhiều grid/container khác nhau.
- Hỗ trợ thêm cấu trúc thống kê API TikTok dạng `itemInfo.itemStruct`, `aweme_info` và các trường chỉ số phẳng của video tải sau.
- Video thiếu dữ liệu ngày/chỉ số luôn được đặt cuối danh sách thay vì chen lên đầu khi sắp xếp tăng dần.

- Sửa card TikTok tái sử dụng bị kế thừa trạng thái ẩn/thứ tự của video cũ, giúp lọc lại ổn định sau nhiều lần cuộn và tải thêm.
- Tối ưu nhận diện cấu trúc card bằng bộ nhớ đệm theo từng lượt quét, giảm đáng kể truy vấn DOM lặp khi có nhiều video.
- Chỉ theo dõi thay đổi liên quan đến kết quả tìm kiếm và chỉ đọc phản hồi API tìm kiếm, tránh quét lại toàn trang hoặc phân tích API không liên quan.
- Không phân tích lặp dữ liệu JSON nhúng đã đọc; giảm CPU/RAM khi trang TikTok mở lâu.
- Chuẩn hóa chính xác số Việt/Anh dạng 1,2K, 1.2K, 1.234, 1,5Tr, triệu và tỷ.
- Giảm tần suất quét dự phòng của player, vẫn giữ quét tức thời qua MutationObserver, scroll và sự kiện chuyển trang TikTok SPA.

- Giữ nguyên video thay thế HD, tải video, copy frame và điều khiển Playback.
- Autoplay luôn bật mặc định; chỉ Background Play và Smart Auto-Pause mặc định OFF.
- Khi Chrome chặn autoplay có âm thanh, video tự phát im lặng rồi bật tiếng ở thao tác chạm đầu tiên mà không làm dừng video.
- Sửa player bị dính vào video cũ khi cuộn: chọn video theo diện tích thực trong viewport và quét lại ngay khi scroll.
- Popup bộ lọc tìm kiếm chỉ còn công tắc bật/tắt; các điều kiện chi tiết nằm trên bảng lọc của trang TikTok.
- Bộ lọc nhận diện card qua nhiều cấu trúc DOM, đọc số liệu API/DOM và hỗ trợ số Việt hóa như 1,2K/3Tr.
- Nút tải thêm tự quét nhiều đợt, chờ TikTok nạp kết quả mới, bấm nút tải gốc nếu có và áp dụng lại bộ lọc khi hoàn tất.
- Bỏ nút tam giác áp dụng lại; lọc và sắp xếp tự chạy khi thay đổi điều kiện.
- Tải thêm theo chế độ quét nền: giữ thanh bộ lọc cố định, khôi phục chính xác vị trí trang và chỉ hiển thị kết quả sau khi áp dụng lại bộ lọc.
- Hook giữ bộ nhớ đệm thống kê và gửi lại theo yêu cầu, tránh mất lượt thích/bình luận/chia sẻ/lưu khi API trả dữ liệu trước giao diện.
- Tự áp lại bộ lọc nhiều nhịp sau khi tải và sau khi TikTok thay thế card DOM; không ghi nhầm trạng thái ẩn thành kiểu hiển thị gốc.
- Nút reset trên thanh công cụ xóa mọi điều kiện, trả sắp xếp mặc định và gỡ toàn bộ trạng thái card bị ẩn còn sót.
- Sắp xếp bằng thuộc tính CSS `order`, không tháo/gắn lại node do React/TikTok quản lý; lọc và reset tiếp tục hoạt động sau mốc 24 video.
- Chọn container có nhiều card trực tiếp nhất, tránh nhận nhầm layout flex bên trong từng card khi kết quả tăng lên 94+ video.
- Cuộn thủ công tự cập nhật tổng số và áp lại bộ lọc sau khi dừng cuộn; hỗ trợ cả window lẫn container cuộn nội bộ.
- Theo dõi thay đổi `href`, nội dung card và dấu vân tay toàn bộ Video ID để nhận card TikTok tái sử dụng mà không thêm node mới.
- Khôi phục tên tài khoản, dấu xác minh, caption và hashtag trên video thay thế; ưu tiên dữ liệu DOM rồi dự phòng API.
- Tên tài khoản mở được trang profile; từng hashtag mở được trang tag TikTok tương ứng.
- Tick xanh dùng badge SVG đầy đủ và chỉ hiển thị khi DOM/API báo tài khoản đã xác minh.
- Play/Pause chỉ xuất hiện sau thao tác click vào video, kèm hiệu ứng zoom-out rồi tự ẩn.
- Audio Studio: Equalizer 8 băng tần với 8 preset và EQ tùy chỉnh.
- Adaptive Volume Normalizer cân RMS, nén đỉnh lớn và hạn chế chênh lệch âm lượng.
- Âm thanh không gian 360° dùng HRTF, có chỉnh cường độ và tự quay quanh người nghe.
- Tự trở về âm thanh gốc nếu máy chủ video không cho phép xử lý Web Audio/CORS.
- Nhận đúng Video ID ở trang chi tiết, trang chủ và các data attribute do extension khác chèn.
- Bảng chỉ số căn giữa, nhỏ gọn: ngày, views, ER, tim, bình luận, chia sẻ và lưu.
- Bấm bảng để copy; kéo để di chuyển và nhớ vị trí; nhấp đúp để đặt lại chính giữa.
- Đồng bộ phụ đề TikTok Subtitle Translator hoặc lấy sub qua Transcript365.
- Tối ưu quét DOM/Shadow DOM, cập nhật vị trí player, cache video và listener trên TikTok SPA.
- Chặn video gốc tự phát; chỉ video thay thế phát âm thanh.
- Sửa số phiên bản hiển thị trong popup và giảm quyền không sử dụng.
- Fix triệt để lấy subtitle: đọc lớp inline, TextTrack và tự dựng cue từ bảng transcript có timestamp.
- Đồng bộ timeupdate/play/pause/seek giữa video thay thế và video nguồn mà không phát âm thanh video gốc.
PHIÊN BẢN 2.8.9
- Thêm Clean Mode trên thanh video và trong popup: ẩn caption/tên tài khoản, phụ đề, thống kê, tiến trình, âm lượng, tải HD và toàn bộ nút phủ.
- Phím C bật/tắt Clean Mode ngay cả khi toàn bộ nút trên video đang ẩn; trạng thái được ghi nhớ cho các video tiếp theo.
- Giữ nguyên toàn bộ tính năng và phím tắt của v2.8.8.
PHIÊN BẢN 2.9.0
- Sửa fullscreen màn hình đen: fullscreen đúng container chứa cả video light DOM và lớp điều khiển Shadow DOM.
- Clean Mode luôn giữ một icon mờ ở cạnh phải để bật lại toàn bộ nút; vẫn hỗ trợ phím C.
- Clean Mode che giao diện extension phụ đề/ShortKit khác trong vùng video bằng trạng thái hiển thị tạm thời, không xóa node/listener và khôi phục khi tắt.
PHIÊN BẢN 2.9.1
- Sửa triệt để fullscreen màn hình đen bằng cách fullscreen trực tiếp lớp light DOM đang chứa video thay thế.
- Tạm đưa Shadow DOM điều khiển vào cùng fullscreen layer, sau đó tự khôi phục đúng vị trí khi thoát hoặc khi Fullscreen API lỗi.
- Tính lại vùng video theo kích thước màn hình fullscreen; giữ nguyên Clean Mode, phụ đề, Audio Studio và toàn bộ chức năng cũ.
PHIÊN BẢN 2.10.0
- Thêm quét sản phẩm theo Video ID từ TikTok commerce anchors giống luồng dữ liệu ShortKit.
- Widget sản phẩm hiển thị ảnh, tên, giá khi có, Seller ID, SKU, danh mục, lượt bán và nút mở TikTok Shop.
- Tự cập nhật trên TikTok SPA/trang hồ sơ/modal video; bổ sung dữ liệu DOM khi ShortKit hoặc TikTok đã tải chi tiết giá.
- Có nút bật/tắt trong popup; Clean Mode tự ẩn widget và toàn bộ tính năng cũ được giữ nguyên.
PHIÊN BẢN 2.10.1
- Sửa widget không hiển thị: lấy sản phẩm hoàn toàn từ dữ liệu TikTok, không dùng dữ liệu ShortKit.
- Hook trực tiếp phản hồi fetch/XHR của TikTok để nhận commerce anchors khi chuyển video hoặc tải video mới trong SPA.
- Kết hợp hydration TikTok, cache API theo Video ID và anchor TikTok Shop trong đúng player hiện tại.
- Giữ chính xác Product/Seller/SKU ID 19 chữ số và giữ nguyên toàn bộ chức năng cũ.
PHIÊN BẢN 2.10.1 UI
- Giữ nguyên toàn bộ chức năng và luồng quét sản phẩm của v2.10.1.
- Làm lại widget sản phẩm dạng pill hồng ở góc dưới bên phải theo ảnh mẫu, tên sản phẩm tự rút gọn.
- Bảng chi tiết glassmorphism mở phía trên, ảnh lớn hơn và bố cục giá/thông tin/nút TikTok Shop rõ ràng hơn.
PHIÊN BẢN 2.10.1 UI.2
- Giữ nguyên toàn bộ chức năng; widget bình thường chỉ còn nút tròn giỏ hàng ở góc phải video.
- Rê chuột để nút tự mở rộng; tên sản phẩm dài tự cuộn ngang với tốc độ theo độ dài nội dung.
- Hover không mở bảng; chỉ click nút giỏ hàng mới hiển thị bảng chi tiết sản phẩm.
=== v2.11.0 - TikTok-only Thailand Proxy ===

- Giữ nguyên toàn bộ tính năng video, fullscreen, Clean Mode, phụ đề, tải HD, Audio Studio, bộ lọc và widget sản phẩm.
- Thêm công tắc proxy Thái Lan ngay trong popup; chỉ hệ sinh thái miền TikTok đi qua proxy, website khác luôn DIRECT.
- Lấy danh sách từ ProxyScrape theo đúng API country=th và hỗ trợ HTTP, HTTPS, SOCKS4, SOCKS5.
- Mỗi hồ sơ cài đặt có mã ngẫu nhiên riêng, chọn proxy ngẫu nhiên và tránh lặp lại 30 proxy đã dùng gần nhất.
- Có nút "Đổi proxy" để chuyển nhanh khi proxy công cộng chậm hoặc ngừng hoạt động.
=== v2.12.0 - Multi-country Proxy ===

- Giữ nguyên toàn bộ chức năng của v2.11.0.
- Nguồn tổng hợp ProxyScrape: country=th%2Cvn%2Ckh.
- Thêm lựa chọn quốc gia bằng quốc kỳ: Việt Nam, Thái Lan và Campuchia.
- Tự đối chiếu danh sách tổng hợp với danh sách từng quốc gia để nhận diện và gắn đúng quốc gia cho proxy.
- Khi đổi quốc gia lúc proxy đang bật, extension tự chọn proxy mới đúng vùng và áp dụng ngay cho riêng TikTok.
=== v2.13.0 - Fastest Proxy Auto Test ===

- Giữ nguyên toàn bộ chức năng của v2.12.0.
- Mỗi lần bật, đổi proxy hoặc đổi quốc gia: lấy tối đa 7 ứng viên chưa dùng gần đây và đo phản hồi thực tế qua TikTok.
- Tự động chọn proxy có độ trễ thấp nhất trong các proxy vượt qua bài kiểm tra.
- Lưu độ trễ và số proxy đã test để hiển thị trong popup.
- Tự tải lại toàn bộ tab TikTok sau khi proxy mới được áp dụng thành công.
- Nếu toàn bộ proxy test lỗi, khôi phục proxy đang dùng trước đó thay vì để lại cấu hình thử nghiệm.
=== v2.14.0 - Instant Random + Background Speed Test ===

- Giữ nguyên toàn bộ chức năng của v2.13.0.
- Áp dụng ngay một proxy ngẫu nhiên đúng quốc gia, không bắt người dùng chờ hoàn tất bài test tốc độ.
- Tiếp tục kiểm tra tối đa 7 proxy dưới nền, sau đó tự chuyển sang proxy phản hồi TikTok nhanh nhất.
- Tải lại TikTok khi proxy ngẫu nhiên được áp dụng và tải lại lần nữa khi chuyển sang proxy nhanh nhất.
- Mỗi lượt test có mã phiên riêng; lượt mới sẽ vô hiệu hóa kết quả lượt cũ để tránh đổi proxy chồng chéo.
- Nếu toàn bộ bài test nền thất bại, tự khôi phục cấu hình proxy trước đó.
=== v2.15.0 - Random Proxy + Realtime Latency ===

- Giữ nguyên toàn bộ chức năng của v2.14.0.
- Bỏ hoàn toàn quy trình thử nhiều proxy và tự chuyển sang proxy nhanh nhất.
- Mỗi lần bật/đổi quốc gia/bấm Đổi proxy chỉ chọn một proxy ngẫu nhiên rồi giữ nguyên.
- Popup đo độ trễ realtime của chính proxy đang dùng, không đổi proxy và vẫn hiển thị giao thức HTTP/HTTPS/SOCKS4/SOCKS5.
- Dừng đo khi popup đóng để không tạo lưu lượng kiểm tra nền không cần thiết.

=== v2.15.1 - Stability & Performance Optimized ===

- Giữ nguyên toàn bộ tính năng của v2.15.0 và toàn bộ cài đặt người dùng hiện có.
- Khóa tuần tự thao tác bật, tắt, đổi quốc gia và đổi proxy để không còn cấu hình chạy chồng.
- Chống kết quả đo độ trễ cũ ghi đè proxy vừa đổi; giao diện, storage và PAC luôn cùng một endpoint.
- Tắt proxy cũng tự tải lại tab TikTok; các lần đổi liên tiếp được gom để tránh reload trùng.
- Cache ngắn danh sách ProxyScrape theo quốc gia và dùng lại yêu cầu đang tải, giúp bật/đổi proxy nhanh hơn.
- Không đặt lại alarm mỗi lần service worker thức dậy; giảm đọc/ghi toàn bộ cache phụ đề không cần thiết.
- Chặn vòng lặp MutationObserver khi ẩn lớp phụ đề nguồn; giảm quét sâu DOM khi đã nhận đúng subtitle inline.
- Giảm polling storage của Transcript365 nhưng vẫn nhận kết quả tức thời qua sự kiện thay đổi.
- Giới hạn an toàn số node khi phân tích dữ liệu sản phẩm và tăng cache âm cho video không gắn sản phẩm.
- Gộp quét thống kê và TikTok Shop trong cùng một lượt duyệt phản hồi API thay vì duyệt hai lần.
- Cache dữ liệu DOM của card tìm kiếm giữa các lượt áp bộ lọc; tự làm mới khi TikTok thay card hoặc đổi nội dung.

=== v2.16.0 - Server User Control & Usage Statistics ===

- Mỗi bản cài có một Client ID ngẫu nhiên 32 ký tự để quản trị, không dùng tên hay tài khoản TikTok.
- Gửi heartbeat và bộ đếm tổng hợp: lấy thông tin video, tải video, lấy/dịch phụ đề, dịch từ khóa và đổi proxy.
- Không gửi cookie, mật khẩu, nội dung phụ đề/từ khóa, URL đã xem hoặc lịch sử duyệt web.
- Dashboard server cho phép khóa/mở khóa từng Client ID, gán Whitelist/Blacklist, ghi chú và xuất JSON.
- Hỗ trợ ba chế độ toàn hệ thống: Open, Whitelist và Blacklist; người bị khóa sẽ dừng player, proxy, dịch và bộ lọc.
- Quyền bị khóa được nhớ cục bộ khi server tạm mất kết nối, tránh tự mở khóa ngoài ý muốn.
- Mặc định fail-open cho người đang được phép; có thể đổi `failMode` thành `closed` trong `remote_config.js`.

Cấu hình server:

1. Giải nén gói `TDT_Extension_Control_Server_v1.0.0.zip`, tạo biến `TDT_ADMIN_TOKEN` dài tối thiểu 16 ký tự rồi chạy `npm start`.
2. Mở `/admin`, nhập token để quản lý người dùng.
3. Sửa `serverUrl` trong `remote_config.js` thành URL HTTPS của server.
4. Thêm đúng origin server vào `host_permissions` của `manifest.json`, ví dụ `https://control.example.com/*`.
5. Giữ `projectKey` của extension trùng với biến `TDT_PROJECT_KEY` trên server.

=== v2.17.0 - Firebase Realtime Lock & Fail-Closed ===

- Chuyển quản trị sang Firebase Hosting, Cloud Functions v2, Firestore và Realtime Database.
- Dùng Firebase Anonymous Auth; UID và Client ID được liên kết phía server để tránh giả mạo Client ID đơn giản.
- Nhận lệnh khóa/mở khóa tức thời qua hai luồng SSE cho cấu hình toàn hệ thống và quyền của UID hiện tại.
- Mọi phiên được phép chỉ có lease tối đa 90 giây; thao tác nền luôn xác minh lease trước khi chạy.
- Không tin trạng thái `allowed` trong storage sau khi Service Worker khởi động lại.
- Mất server, mất realtime, token hết hạn hoặc cấu hình sai đều tự khóa theo cơ chế fail-closed.
- Player, proxy, dịch từ khóa, bộ lọc tìm kiếm và widget đều dừng ngay khi nhận trạng thái khóa.
- Mặc định backend Firebase ở chế độ Whitelist, nên xóa storage/cài lại sẽ tạo UID mới nhưng không tự được cấp quyền.
- Hỗ trợ khóa đúng Extension ID để giảm việc repack bản phát hành.

Giới hạn bảo mật: source JavaScript chạy trên máy người dùng không thể chống sửa tuyệt đối. Để khóa không thể bị vượt qua, API/dữ liệu có giá trị phải nằm phía server và kiểm tra quyền trên từng request.

=== BẢN PRODUCTION v2.17 ĐÃ CẤU HÌNH: tran-duc-tai ===

- Dashboard quản trị: https://tran-duc-tai.web.app
- Realtime Database: https://tran-duc-tai-default-rtdb.asia-southeast1.firebasedatabase.app
- Host permissions đã thu hẹp chỉ còn đúng Hosting/Database của dự án, Firebase Auth và các API chức năng cần thiết.
- Mặc định Whitelist + fail-closed; người dùng mới phải được cấp Whitelist trên dashboard.
- Admin token không nằm trong extension hoặc gói mã nguồn.

=== v2.18.0 - Google Login & Dashboard Account ===

- Ẩn hoàn toàn bảng “Quyền truy cập server” và Client ID khỏi popup; popup chỉ hiển thị tài khoản Google cùng trạng thái kích hoạt.
- Mở trang chào mừng ở lần cài đầu tiên và yêu cầu Google Sign-In trước khi dùng mọi tính năng.
- Backend chỉ chấp nhận Firebase ID token có provider `google.com`; phiên Anonymous cũ không còn quyền.
- Tài khoản Google lần đầu đăng ký tự động được Whitelist, sau đó admin vẫn có thể khóa, đưa vào Blacklist hoặc chuyển Neutral.
- Chrome Extension ID được cố định là `cpndheccadlhkiogcfdhagomiadbaogn` để Firebase Authorized Domains và backend chỉ chấp nhận đúng bản phát hành.
- Bổ sung thống kê mở popup, đăng nhập Google, đo proxy, Clean Mode, sản phẩm, bộ lọc, thiết bị, trình duyệt, phiên và ngày hoạt động.
- Dashboard mới dùng tên đăng nhập/mật khẩu; mặc định lần đầu `admin / admin`, có cảnh báo đổi ngay và đổi tài khoản sẽ vô hiệu các phiên cũ.
- Tiếp tục fail-closed: không đăng nhập, mất Firebase, token lỗi, lease hết hạn, bị khóa hoặc Blacklist đều dừng chức năng.

Production v2.18:

- Dashboard: https://tran-duc-tai.web.app
- Extension ID: cpndheccadlhkiogcfdhagomiadbaogn
- Google Sign-In dùng trang trung gian Firebase Hosting tại `/auth/` theo mô hình Offscreen Document của Manifest V3.
- Không gửi mật khẩu Google, cookie, URL TikTok hoặc lịch sử duyệt web.

- Widget T góc trái dưới tích hợp Watch-time; click vẫn mở công cụ nhanh cũ.

## v2.20.7
- Chặn thay video nhầm trong khu vực “Bạn có thể thích” bằng nhận diện Right Panel và đối chiếu Video ID với URL tab.
- Player đang hoạt động đúng không còn bị quét và chuyển sang preview khác khi DOM TikTok cập nhật.
- Thông báo trạng thái mới dạng Dynamic Island Notch, responsive và có hiệu ứng trạng thái.
- Tối ưu MutationObserver, chu kỳ lifecycle, startup scans và thống kê phụ đề để giảm CPU/RAM.


## v2.3.7
- Giữ nguyên toàn bộ chức năng từ extension final.
- Tối ưu vòng quét player khi tab nền và giảm polling popup.
- Gom xử lý scroll để giảm CPU khi cuộn trang TikTok.
- Dọn metadata thừa trong gói ZIP.


## v2.3.9
- Giữ nguyên toàn bộ tính năng v2.3.7.
- Tự khóa khi có phiên bản bắt buộc mới hơn.
- Hiện popup cập nhật bắt buộc và badge UP.
- Chuyển trung tâm cập nhật lên nút phiên bản ở đầu popup.
- Nhận lệnh update realtime từ Dashboard admin.
- Tối ưu đồng bộ, giảm polling và chống mở trùng popup.

## v2.4.1
- Tìm kiếm ảnh 1688 ở tab nền và chỉ hiện tab kết quả có imageId/imageIdList.
- Nút 1688 nhỏ trong thanh điều khiển video; phím tắt F.
- Nút tìm ảnh trên sản phẩm TikTok Shop được Extension quét.
- Nút tìm ảnh trên từng ảnh sản phẩm phù hợp tại shop.tiktok.com.
- Tối ưu observer, bộ nhớ ảnh tạm và dọn tab/dữ liệu sau khi hoàn tất.

## v2.4.2
- Sửa luồng 1688 mới: sau khi tải ảnh, tự nhận diện bước xác nhận “Một hình ảnh đã được tải lên”.
- Tự bấm nút `.copy-image-container .search-btn` / “Tìm kiếm hình ảnh” để chuyển sang trang kết quả có imageId/imageIdList.
- Hỗ trợ trường hợp 1688 mở kết quả trong tab mới: tự chuyển ánh xạ yêu cầu, kích hoạt tab kết quả và đóng tab tải ảnh nền.
- Không đưa tab tải ảnh cũ ra trước nếu tab kết quả đã hoàn tất.
- Giảm polling, tăng selector dự phòng và thêm retry cho giao diện 1688 tải động.
- Giữ nguyên nút 1688 trong player, phím F, nút ảnh TikTok Shop và toàn bộ chức năng cũ.


## v2.4.3
- Chuyển toàn bộ thao tác tạo File/DataTransfer và phát sự kiện upload sang MAIN world của trang 1688 để React nhận đúng file ảnh.
- Chỉ báo ảnh đã tải sau khi preview thật sự xuất hiện; không còn trạng thái giả do chỉ gán input.files.
- Bỏ scrollIntoView, không bấm các phần tử chung chung và giữ nguyên vị trí cuộn của trang 1688.
- Tự bấm đúng nút xác nhận ảnh sau khi preview sẵn sàng và giữ cơ chế nhận tab kết quả imageId/imageIdList.
- TikTok Shop chạy module riêng trong mọi frame tiktok.com, nhận diện ảnh IMG và ảnh nền CSS.
- Nới nhận diện ảnh trên shop.tiktok.com, chống tạo trùng nút khi SPA render lại và debounce quét để giảm CPU.


## v2.4.4
- Giữ nguyên toàn bộ chức năng v2.4.3.
- Mỗi lần tìm kiếm hình ảnh 1688 chỉ giữ duy nhất một tab kết quả.
- Chống gửi trùng khi bấm nút hoặc phím F liên tiếp.
- Tự đóng tab tải ảnh nền và mọi tab kết quả trùng cùng imageId/imageIdList.
- Không hủy yêu cầu đang chạy khi một tab trùng bị đóng.

## v2.5.3
- Giữ nguyên toàn bộ chức năng v2.5.2.
- Sửa PAC cho proxy HTTPS từ ProxyScrape: dùng HTTP CONNECT `PROXY` đúng chuẩn thay vì directive `HTTPS` gây lỗi kết nối.
- Chỉ lưu proxy sau khi Chrome áp dụng PAC và proxy phản hồi được TikTok; tự thử tối đa 4 proxy ngẫu nhiên đúng quốc gia.
- Sửa video đã tạm dừng tự phát lại do mở khóa âm thanh, tải xong phụ đề, chuyển tab hoặc TikTok render lại player.
- Ghi nhớ trạng thái tạm dừng theo từng video; thao tác Play của người dùng mới được phép xóa trạng thái này.
- Sửa giao diện đồng bộ online trong popup bị thiếu nút và trạng thái đồng bộ.
- Bổ sung kiểm tra toàn bộ file JavaScript, Manifest V3, tham chiếu HTML và luồng proxy/player mô phỏng.
