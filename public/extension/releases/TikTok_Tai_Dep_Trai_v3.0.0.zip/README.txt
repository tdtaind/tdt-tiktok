TIKTOK TÀI ĐẸP TRAI v3.0.0

CÀI ĐẶT
1. Giải nén file ZIP.
2. Mở chrome://extensions.
3. Bật Chế độ dành cho nhà phát triển.
4. Chọn Tải tiện ích đã giải nén và chọn thư mục chứa manifest.json.
5. Tải lại tab TikTok đang mở.

ĐIỂM CHÍNH CỦA BẢN 3.0.0 HD HOTFIX
- Giữ nguyên toàn bộ chức năng gốc và Extension ID.
- Thay thế đúng video tại trang chủ, tìm kiếm, hồ sơ và trang chi tiết.
- Chỉ hiển thị player thay thế; video native bị pause, mute và ẩn hoàn toàn.
- Ưu tiên nguồn có bitrate cao nhất từ dữ liệu feed TikTok.
- Kiểm tra Video ID của nguồn API trước khi phát để ngăn lấy nhầm video.
- Dừng hoàn toàn âm thanh/player cũ khi chuyển video.
- Giảm quét DOM, Shadow DOM và MutationObserver để TikTok mượt hơn.

TÀI LIỆU
- RELEASE_NOTES_v3.0.0.txt: danh sách thay đổi.
- TEST_REPORT_v3.0.0.txt: kết quả kiểm thử.
- HUONG_DAN_CAP_NHAT.txt và SELF_HOSTED_UPDATE.md: hướng dẫn cập nhật riêng.
