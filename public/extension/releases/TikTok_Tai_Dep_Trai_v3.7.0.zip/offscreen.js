"use strict";

const AUTH_PAGE_URL = "https://tdt-firebase-control.vercel.app/auth/?v=2.1.2";
const AUTH_PAGE_ORIGIN = new URL(AUTH_PAGE_URL).origin;
const iframe = document.createElement("iframe");
iframe.src = AUTH_PAGE_URL;
iframe.title = "TDT Google Sign-In";
iframe.setAttribute("aria-hidden", "true");
Object.assign(iframe.style, {
  position: "fixed",
  width: "1px",
  height: "1px",
  border: "0",
  opacity: "0",
  pointerEvents: "none"
});
document.documentElement.appendChild(iframe);

let readyState = "loading";
let readyError = "";
let resolveReady;
let rejectReady;
const authPageReady = new Promise((resolve, reject) => {
  resolveReady = resolve;
  rejectReady = reject;
});

const readyTimeout = setTimeout(() => {
  if (readyState !== "loading") return;
  readyState = "failed";
  readyError = "Trang Firebase Auth chưa phản hồi. Hãy deploy Dashboard v2.1.2 Hosting rồi thử lại.";
  rejectReady(new Error(readyError));
}, 20_000);

iframe.addEventListener("error", () => {
  if (readyState !== "loading") return;
  clearTimeout(readyTimeout);
  readyState = "failed";
  readyError = "Không tải được trang Firebase Auth. Hãy kiểm tra mạng, DNS hoặc Firebase Hosting.";
  rejectReady(new Error(readyError));
}, { once: true });

globalThis.addEventListener("message", (event) => {
  if (event.origin !== AUTH_PAGE_ORIGIN || event.source !== iframe.contentWindow) return;
  const data = event.data;
  if (!data || data.namespace !== "tdt-google-auth" || data.action !== "ready") return;
  if (readyState !== "loading") return;
  clearTimeout(readyTimeout);
  if (data.ok === true) {
    readyState = "ready";
    resolveReady(data);
  } else {
    readyState = "failed";
    readyError = data.error || "Firebase Auth khởi tạo thất bại.";
    rejectReady(new Error(readyError));
  }
});

let requestInFlight = null;

function requestGoogleSignIn() {
  if (requestInFlight) return requestInFlight;
  requestInFlight = authPageReady.then(() => new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      globalThis.removeEventListener("message", handleMessage);
      reject(new Error("Cửa sổ Google không phản hồi sau 90 giây. Hãy tắt trình chặn popup rồi thử lại."));
    }, 90_000);

    function handleMessage(event) {
      if (event.origin !== AUTH_PAGE_ORIGIN || event.source !== iframe.contentWindow) return;
      const data = event.data;
      if (!data || data.namespace !== "tdt-google-auth" || data.action !== "result") return;
      clearTimeout(timeout);
      globalThis.removeEventListener("message", handleMessage);
      resolve(data);
    }

    globalThis.addEventListener("message", handleMessage);
    iframe.contentWindow.postMessage(
      { namespace: "tdt-google-auth", action: "sign-in" },
      AUTH_PAGE_ORIGIN
    );
  })).finally(() => {
    requestInFlight = null;
  });
  return requestInFlight;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== "tdt-google-auth-offscreen") return false;
  void requestGoogleSignIn()
    .then((result) => sendResponse({ ok: result?.ok === true, ...result }))
    .catch((error) => sendResponse({
      ok: false,
      error: error?.message || readyError || "Đăng nhập Google thất bại."
    }));
  return true;
});
